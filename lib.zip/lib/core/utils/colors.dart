

import 'dart:ui';

import 'package:flutter/material.dart';

class ColorsApp{
  static Color scaffoldColor=Colors.grey[300]!;
  static Color AppBarColor=Colors.teal;
  static Color whiteColor=Colors.white;
  static Color blackColor=Colors.black;
  static Color defualtColor=Colors.teal;
  static Color buttonColor=Colors.teal;
}