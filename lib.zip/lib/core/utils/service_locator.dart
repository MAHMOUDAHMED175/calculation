

import 'package:cache_repo/core/utils/dioHelper.dart';
import 'package:get_it/get_it.dart';

final getIt = GetIt.instance;

void setupServiceLocator() {
  getIt.registerSingleton<DioHelper>(DioHelper());

//الطريقه دى غلط المفروض ان  هوا المسؤول عن غلق الcubit ولما بيخلص شغله بيقفل نفسه اما لو عملته زى اللى تحت فى git it مش هيتقفل خالص blocprovider
  // getIt.registerSingleton<StoreCubit>(StoreCubit(
  //   getIt.get<DioHelper>(),
  // ));
}
