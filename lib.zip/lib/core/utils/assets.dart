class AssetsData {
  static const logo = 'assets/images/Logo.png';
  static const testImage = 'assets/images/money.jpg';
}
