import 'package:cache_repo/confg/app_route.dart';
import 'package:cache_repo/confg/observer.dart';
import 'package:cache_repo/core/utils/colors.dart';
import 'package:cache_repo/core/utils/dioHelper.dart';
import 'package:cache_repo/core/utils/service_locator.dart';
import 'package:cache_repo/features/buy/presentaion/views_models/managers/cubit/buy_cubit.dart';
import 'package:cache_repo/features/representatives/presentaion/views_models/managers/representatives_cubit.dart';
import 'package:cache_repo/features/sell/presentaion/views_models/managers/cubit/sell_cubit.dart';
import 'package:cache_repo/features/store/presentaion/views_models/managers/cubit/cubit.dart';
import 'package:cache_repo/features/suppliers/presentaion/views_models/managers/cubit/supplires_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  Bloc.observer = MyBlocObserver();
  await DioHelper.Init();
  setupServiceLocator();
  runApp(const CacheRepo());
}

class CacheRepo extends StatelessWidget {
  const CacheRepo({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
        providers: [
          BlocProvider(create: (BuildContext context) {
            return StoreCubit()..CreateDatabase();
            // ..ProductTree()
            // ..FechProducts();
          }),
          BlocProvider(create: (BuildContext context) {
            return BuyCubit();
          }),
          BlocProvider(create: (BuildContext context) {
            return SellCubit();
          }),
          BlocProvider(create: (BuildContext context) {
            return RepresentativesCubit()..CreateDatabaseRepresent();
          }),
          BlocProvider(create: (BuildContext context) {
            return SuppliersCubit()..CreateDatabaseSuppliers();
          }),
        ],
        child: MaterialApp.router(
          routerConfig: AppRoute.router,
          // home: ImageScreen(),
          debugShowCheckedModeBanner: false,
          theme: ThemeData.light().copyWith(
            scaffoldBackgroundColor: ColorsApp.scaffoldColor,
            textTheme:
                GoogleFonts.montserratTextTheme(ThemeData.light().textTheme),
          ),
        ));
  }
}







class CalculatorScreen extends StatefulWidget {
  @override
  _CalculatorScreenState createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  String _output = '';
  double _num1 = 0;
  double _num2 = 0;
  String _operator = '';

  void _buttonPressed(String buttonText) {
    setState(() {
      if (buttonText == 'C') {
        _output = '';
        _num1 = 0;
        _num2 = 0;
        _operator = '';
      } else if (buttonText == '+' ||
          buttonText == '-' ||
          buttonText == '*' ||
          buttonText == '/') {
        _num1 = double.parse(_output);
        _operator = buttonText;
        _output = '';
      } else if (buttonText == '=') {
        _num2 = double.parse(_output);
        if (_operator == '+') {
          _output = (_num1 + _num2).toString();
        }
        if (_operator == '-') {
          _output = (_num1 - _num2).toString();
        }
        if (_operator == '*') {
          _output = (_num1 * _num2).toString();
        }
        if (_operator == '/') {
          _output = (_num1 / _num2).toString();
        }
        _num1 = 0;
        _num2 = 0;
        _operator = '';
      } else {
        _output += buttonText;
      }
    });
  }

  Widget _buildButton(String buttonText) {
    return Expanded(
      child: MaterialButton(
        padding: EdgeInsets.all(24.0),
        onPressed: () => _buttonPressed(buttonText),
        child: Text(
          buttonText,
          style: TextStyle(fontSize: 20.0),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
        title: Text('Calculator'),
    ),
    body: Column(
    children: <Widget>[
    Container(
    alignment: Alignment.centerRight,
    padding: EdgeInsets.symmetric(vertical: 24.0, horizontal: 12.0),
    child: Text(
    _output,
    style: TextStyle(fontSize: 48.0, fontWeight: FontWeight.bold),
    ),
    ),
    Expanded(
    child: Divider(),
    ),
    Column(
    children: [
    Row(
    children: [
    _buildButton('7'),
    _buildButton('8'),
    _buildButton('9'),
    _buildButton('/'),
    ],
    ),
    Row(
    children: [
    _buildButton('4'),
    _buildButton('5'),
    _buildButton('6'),
    _buildButton('*'),
    ],
    ),
    Row(
    children: [
    _buildButton('1'),
    _buildButton('2'),
    _buildButton('3'),
    _buildButton('-'),
    ],
    ),
    Row(
    children: [
    _buildButton('.'),
    _buildButton('0'),
    _buildButton('00'),
    _buildButton('+'),
    ],
    ),
    Row(
    children: [
    _buildButton('C'),
      _buildButton('C'),
      _buildButton('='),
    ],
    ),
    ],
    ),
    ],
    ),
    );
  }
}
