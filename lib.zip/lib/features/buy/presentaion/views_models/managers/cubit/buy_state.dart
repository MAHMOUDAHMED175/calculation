abstract class BuyState {}

class BuyInitial extends BuyState {}

///deleteItemBuyProductState
class deleteItemBuyProductState extends BuyState {}

///deleteItemBuyProductState

class searchProductSellState extends BuyState {}

///addProductToBuyState
class addProductToBuyState extends BuyState {}

class addProductFloatingActionButton extends BuyState {}

class addProductFloatingActionButton2 extends BuyState {}

///addProductToBuyState

class buyRemainingPaymentFloatingActionButtonState extends BuyState {}
