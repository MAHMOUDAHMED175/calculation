
abstract class SellState {}

class SellInitial extends SellState {}





///deleteItemSellProductState
class deleteItemSellProductState extends SellState{}
///deleteItemSellProductState





class searchProductState extends SellState{}

///addProductToSellState
class addProductToSellState extends SellState{}
class addProductFloatingActionButton extends SellState{}
class addProductFloatingActionButton2 extends SellState{}
///addProductToSellState





///FloatingActionButton
class remainingPaymentFloatingActionButtonState extends SellState{}
///FloatingActionButton
